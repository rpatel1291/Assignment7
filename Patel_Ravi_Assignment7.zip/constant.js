const API_KEY = '12411287-04a12b9fbec0a5fee22d12b88'


module.exports = API_KEY
